﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */


#include <aws/s3/S3Request.h>

namespace Aws
{
namespace S3
{
} // namespace S3
} // namespace Aws
